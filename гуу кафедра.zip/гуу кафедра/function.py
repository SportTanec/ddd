from aiogram.types import InlineKeyboardMarkup,\
                        InlineKeyboardButton,\
                        ReplyKeyboardMarkup,\
                        KeyboardButton,\
                        ReplyKeyboardRemove
from aiogram.types.message import ContentType
from config import *
import sqlite3, requests, json
from datetime import datetime
import random

class auto_voronka:
    def start():
        key = InlineKeyboardMarkup(row_width = 1)
        for item in AUTO_VORONKA['start']['button']:
            key.add(
                InlineKeyboardButton(
                    text = item['text'], 
                    callback_data = item['callback_data']
                )
            )
        return {
            'text' : AUTO_VORONKA['start']['text'],
            'keyboard' : key,
            'image' : open(AUTO_VORONKA['start']['image'], 'rb') if AUTO_VORONKA['start']['image'] != None else None
        }
    
    def question(question_n : int):
        key = InlineKeyboardMarkup(row_width=1)
        for item in AUTO_VORONKA['questions'][question_n]['answer']:
            key.add(
                InlineKeyboardButton(
                    text = item['text'], 
                    callback_data = f"{question_n}_{item['right']}"
                )
            )
        return {
            'text' : AUTO_VORONKA['questions'][question_n]['text'],
            'keyboard' : key,
            'image' : open(AUTO_VORONKA['questions'][question_n]['image'], 'rb') if AUTO_VORONKA['questions'][question_n]['image'] != None else None
        }

    def annotation(annotation_n : int):
        key = InlineKeyboardMarkup(row_width=1)
        for item in AUTO_VORONKA['questions'][annotation_n]['annotation']['button']:
            key.add(
                InlineKeyboardButton(
                    text = item['text'], 
                    callback_data = item['callback_data']
                )
            )
        return {
            'text' : AUTO_VORONKA['questions'][annotation_n]['annotation']['text'],
            'keyboard' : key
        }
    
    def result(result_k):
        keyboard = InlineKeyboardMarkup(row_width=1)
        for key, item in AUTO_VORONKA['result'].items():
            if result_k in range(int(key.split('-')[0]), int(key.split('-')[1])+1):
                for item1 in item['button']:
                    keyboard.add(
                        InlineKeyboardButton(
                            text = item1['text'], 
                            callback_data = item1['callback_data']
                        )
                    )
            
                return {
                    'text' : f"{result_k} правильных ответов из {len(AUTO_VORONKA['questions'])}\n{item['text']}",
                    'keyboard' : keyboard,
                    'image' : open(item['image'], 'rb') if item['image'] != None else None
                }
    
    def end():
        return {
            'text' : AUTO_VORONKA['end']['text'],
            'keyboard' : None,
            'image' : open(AUTO_VORONKA['end']['image'], 'rb') if AUTO_VORONKA['end']['image'] != None else None
        }

class keyboard():
    def menu():
        key = ReplyKeyboardMarkup(resize_keyboard = True)
        program_learn = KeyboardButton(text = TEXT_MENU['program_learn'])
        contact = KeyboardButton(text = TEXT_MENU['contact'])
        freq_que = KeyboardButton(text = TEXT_MENU['freq_que'])
        why_we = KeyboardButton(text = TEXT_MENU['why_we'])
        rewievs_from_students = KeyboardButton(text = TEXT_MENU['rewievs_from_students'])
        our_partner = KeyboardButton(text = TEXT_MENU['our_partner'])
        key.add(program_learn, our_partner)
        key.add(why_we, freq_que, rewievs_from_students)
        key.add(contact)
        return {
            'text' : START_TEXT,
            'keyboard' : key,
            'image' : open('./pictures/menu.jpg', 'rb')
        }
    
class db():
    def __init__(self):
        self.db = sqlite3.connect('users.db')
        self.cur = self.db.cursor()

    def about(self, id):
        id = str(id)
        self.cur.execute(f"""SELECT * FROM users WHERE id = ?""", (id, ))
        pre_res = self.cur.fetchone()
        return {
            'exist' : True if pre_res != None else False,
            'id' : pre_res[0] if pre_res != None else None,
            'data' : pre_res[1] if pre_res != None else None,
        }
        

    def add(self, id):
        try:
            user_data = requests.get(f'https://api.telegram.org/bot{BOT_TOKEN}/getChat?chat_id={id}').json()['result']
            try:
                user_data = f"{user_data['id']} {user_data['username']} https://t.me/{user_data['username']}"
            except:
                user_data = f"{user_data}"
        except:
            user_data = None
        id = str(id)
        self.cur.execute(f"""INSERT INTO users VALUES (?, ?)""", (id, user_data))
        self.db.commit()
        logg(user_id = id, action = 'new_user')

    def __del__(self):
        self.db.close()

class logg():
    def __init__(self, user_id, action = 'new_user' or 'wonna_contact', d_data = None): # ['new_user', 'wonna_contact']
        self.user_data = requests.get(f'https://api.telegram.org/bot{BOT_TOKEN}/getChat?chat_id={user_id}').json()['result']
        try:
            self._id = f"{self.user_data['id']} {self.user_data['username']} https://t.me/{self.user_data['username']}"
        except:
            self._id = f"{self.user_data}"
        
        if action == 'new_user':
            text = f'{datetime.now().strftime("%Y-%m-%d %H:%M")} - Новый пользователь {self._id} {"ДОП ИНФО : " + d_data if d_data != None else ""}'
            self.write_log(text,action)
            self.send(text)

        elif action == 'wonna_contact':
            text = f'{datetime.now().strftime("%Y-%m-%d %H:%M")} - Пользователь хочет связаться {self._id} {"ДОП ИНФО : " + d_data if d_data != None else ""}'
            self.write_log(text, action)
            self.send(text)    
        
    def send(self, text):
        for id in ADMINS:
            requests.post(f'https://api.telegram.org/bot{ADMIN_BOT_TOKEN}/sendMessage?chat_id={id}&text={text}')
    
    def write_log(self, text, action = 'new_user' or 'wonna_contact'):
        with open('logg.txt', 'a', encoding = 'utf-8') as log_file:
            log_file.write(text+'\n')
        db = sqlite3.connect('users.db')
        cur = db.cursor()
        cur.execute(f"""INSERT INTO log VALUES (?, ?, ?)""", (datetime.now().strftime("%Y-%m-%d %H:%M"), action , self._id ))
        db.commit()
        db.close()
    
def get_stat():
    db = sqlite3.connect('users.db')
    cur = db.cursor()
    res = {
        'wonna_contact' : [],
        'new_user' : []
    }
    cur.execute(f"""
        SELECT * FROM log WHERE type = 'new_user' and date LIKE '{datetime.now().strftime("%Y-%m-%d")}%'
    """)
    res['new_user'] += [len(cur.fetchall())]
    cur.execute(f"""
        SELECT * FROM log WHERE type = 'new_user' and date LIKE '{datetime.now().strftime("%Y-%m")}%'
    """)
    res['new_user'] += [len(cur.fetchall())]
    cur.execute(f"""
        SELECT * FROM log WHERE type = 'new_user'
    """)
    res['new_user'] += [len(cur.fetchall())]


    cur.execute(f"""
        SELECT * FROM log WHERE type = 'wonna_contact' and date LIKE '{datetime.now().strftime("%Y-%m-%d")}%'
    """)
    res['wonna_contact'] += [len(cur.fetchall())]
    cur.execute(f"""
        SELECT * FROM log WHERE type = 'wonna_contact' and date LIKE '{datetime.now().strftime("%Y-%m")}%'
    """)
    res['wonna_contact'] += [len(cur.fetchall())]
    cur.execute(f"""
        SELECT * FROM log WHERE type = 'wonna_contact'
    """)
    res['wonna_contact'] += [len(cur.fetchall())]   
    cur.close(); db.close()  
    return res
