from aiogram import Bot, Dispatcher, types
from aiogram.dispatcher import FSMContext
from aiogram.utils import executor
from function import *
from config import *

bot = Bot(token = ADMIN_BOT_TOKEN, parse_mode = types.ParseMode.HTML)
dp = Dispatcher(bot)
   
@dp.message_handler()
async def stat(message: types.Message, state: FSMContext):
    if message.from_user.id in ADMINS:
        stat_ = get_stat()
        txt = f"""Новых пользователей
Сегодня / Месяц / Всего
{stat_['new_user'][0]} / {stat_['new_user'][1]} / {stat_['new_user'][2]}

Хотят связаться 
Сегодня / Месяц / Всего
{stat_['wonna_contact'][0]} / {stat_['wonna_contact'][1]} / {stat_['wonna_contact'][2]}"""
        await message.answer_document(document = open('logg.txt', 'rb'), caption = txt)

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
