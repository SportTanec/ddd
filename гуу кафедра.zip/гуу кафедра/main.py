import threading
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.utils import executor
from aiogram.types import ReplyKeyboardRemove
from function import *
from config import *

bot = Bot(token = BOT_TOKEN, parse_mode = types.ParseMode.HTML)
storage = MemoryStorage()
dp = Dispatcher(bot, storage = storage)
   
@dp.message_handler(commands = "start")
async def start(message: types.Message, state: FSMContext):
    if db().about(message.from_user.id)['exist']:
        mess = keyboard.menu()
        await message.answer_photo(photo = mess['image'], caption = mess['text'], reply_markup = mess['keyboard'])

    else:
        mess = auto_voronka.start()
        if mess['image'] == None:
            await message.answer(mess['text'], reply_markup = mess['keyboard'])
        else:
            await message.answer_photo(photo = mess['image'], caption = mess['text'], reply_markup = mess['keyboard'])
        await state.set_state('auto_voronka')
        await state.update_data(results = 0)

@dp.callback_query_handler(text = [f'{x}' for x in range(len(AUTO_VORONKA['questions']))], state = ['auto_voronka'])
async def реакция_на_анотации(call: types.CallbackQuery,state: FSMContext):
    async with state.proxy() as data:
        await bot.delete_message(chat_id = call.from_user.id, message_id = call.message.message_id)
        results = int(data.get('results'))  
        question_n = int(call.data)
        mess = auto_voronka.question(question_n = question_n)
        if mess['image'] == None:
            await call.message.answer(mess['text'], reply_markup = mess['keyboard'])
        else:
            await call.message.answer_photo(photo = mess['image'], caption = mess['text'], reply_markup = mess['keyboard'])
        await state.update_data(results = results)


@dp.callback_query_handler(text = [f'{x}_False' for x in range(len(AUTO_VORONKA['questions']))]+[f'{x}_True' for x in range(len(AUTO_VORONKA['questions']))], state = ['auto_voronka'])
async def реакция_на_ответы_на_вопросы(call: types.CallbackQuery,state: FSMContext):
    async with state.proxy() as data:
        await bot.delete_message(chat_id = call.from_user.id, message_id = call.message.message_id)
        results = int(data.get('results'))   
        if call.data.split('_')[1] == 'True':
            results += 1
        # анатация
        anotarion_n = int(call.data.split('_')[0])
        mess = auto_voronka.annotation(annotation_n = anotarion_n)
        await call.message.answer(mess['text'], reply_markup = mess['keyboard'])
        await state.update_data(results = results)

@dp.callback_query_handler(text = 'result', state = ['auto_voronka'])
async def результаты(call: types.CallbackQuery,state: FSMContext):
    async with state.proxy() as data:
        await bot.delete_message(chat_id = call.from_user.id, message_id = call.message.message_id)
        results = int(data.get('results'))   
        mess = auto_voronka.result(result_k = results)
        if mess['image'] == None:
            await call.message.answer(mess['text'], reply_markup = mess['keyboard'])
        else:
            await call.message.answer_photo(photo = mess['image'], caption = mess['text'], reply_markup = mess['keyboard'])
        await state.update_data(results = results)

@dp.callback_query_handler(text = 'end', state = ['auto_voronka'])
async def результаты(call: types.CallbackQuery,state: FSMContext):
    await bot.delete_message(chat_id = call.from_user.id, message_id = call.message.message_id)
    mess = auto_voronka.end()
    if mess['image'] == None:
        await call.message.answer(mess['text'], reply_markup = mess['keyboard'])
    else:
        await call.message.answer_photo(photo = mess['image'], caption = mess['text'], reply_markup = mess['keyboard'])
    await state.finish()
    db().add(call.from_user.id)
    mess = keyboard.menu()
    await call.message.answer_photo(photo = mess['image'], caption = mess['text'], reply_markup = mess['keyboard'])


@dp.message_handler(text = TEXT_MENU['contact'])
async def contact(message: types.Message, state: FSMContext):
    txt = """Это наши контакты.

Сайт: https://up-guu.com/
Группа в ВК: https://vk.com/pm_guu
Контакты для связи:
Телефон для связи +7 (968) 378-60-60
Электронная почта kaf_up@guu.ru"""
    key = InlineKeyboardMarkup(row_width = 1)
    contact_phone_number = InlineKeyboardButton(text = 'По номеру телефона', callback_data = 'contact_phone_number')
    contact_tg = InlineKeyboardButton(text = 'Связаться в Telegram', callback_data = 'contact_tg')
    key.add(contact_phone_number, contact_tg)
    await message.answer(txt, reply_markup = key, disable_web_page_preview = True)

@dp.callback_query_handler(text = ['contact_phone_number', 'contact_tg'])
async def contact_with(call: types.CallbackQuery,state: FSMContext):
    if call.data == 'contact_tg':
        threading.Thread(target = logg, args = (call.from_user.id, 'wonna_contact')).start()
        await call.message.answer(text = 'Ваша заявка принята, мы скоро с вами свяжемся', reply_markup = keyboard.menu()['keyboard'])
    
    else: # contact_phone_number
        mess = {
            'text' : 'Оставьте ваш номер телефона или другие свои контакты, и мы с вами свяжемся',
            'keyboard' : ReplyKeyboardRemove(),
            'image' : open('./pictures/contact_phone_number.jpg', 'rb')
        }
        await call.message.answer_photo(photo = mess['image'], caption = mess['text'], reply_markup = mess['keyboard'])
        await state.set_state('contact_phone_number')
        
@dp.message_handler(state = 'contact_phone_number')
async def contact_phone_number(message: types.Message, state: FSMContext):
    mess = {
        'text' : 'Ваша заявка принята, мы скоро с вами свяжемся',
        'keyboard' : keyboard.menu()['keyboard'],
        'image' : open('./pictures/contact_acc.jpg', 'rb')
    }
    threading.Thread(target = logg, args = (message.from_user.id, 'wonna_contact', message.text)).start()
    await message.answer_photo(photo = mess['image'], caption = mess['text'], reply_markup = mess['keyboard'])
    await state.finish()

@dp.message_handler(text = TEXT_MENU['why_we'])
async def why_we(message: types.Message, state: FSMContext):
    txt = """🔘 Мы первая кафедра “Управление Проектом” в России.
🔘 В нашем преподаватель составе не только теоретики, но и практики, которые работали в крупных компаниях или являлись владельцами бизнеса. 
🔘 Наши выпускники востребованы на рынке труда (Правительство Москвы, Российское энергетическое агентство, Объединенная судостроительная корпорация)
🔘 Трудоустройство выпускников проходит начиная уже с 3 курса!
🔘 Мы помогаем в реализации проектов как в стенах университет, так и за ними.
🔘 Мы используем проектный метод обучения, который позволяет на практике закреплять навыки и знания студентов
"""
    await message.answer_photo(photo = open('pictures/почему мы.jpg', 'rb'), caption = txt)

@dp.message_handler(text = TEXT_MENU['our_partner'])
async def our_partner(message: types.Message, state: FSMContext):
    mess = {
        'text' : """Это компании партнёры, которые уже ждут тебя на стажировку!
    ✅ Правительство Москвы
    ✅ Российское энергетическое агентство
    ✅ Объединенная судостроительная корпорация
    ✅ Фирма “1С
    ✅ Газпром
    ✅ Газпром “НЕФТЬ”
    ✅ Альфа банк
    ✅ АШАН
    ✅ Ростелеком
    ✅ Ernst & Young
    ✅ ENCE GmbH
    ✅ Deloitte
    ✅ РОСАТОМ
    ✅ РОСЭНЕРГОАТОМ
    ✅ GRM GROUP
    ✅ СОВНЕТ/IPMA
    ✅ Real Estate Zemer Consulting & Development
    ✅ НИАРМЕДИК""",
        'keyboard' : None,
        'image' : open('pictures/партнёры.jpg', 'rb')
    }
    await message.answer_photo(photo = mess['image'], caption = mess['text'], reply_markup = mess['keyboard'])

@dp.message_handler(text = TEXT_MENU['program_learn'])
async def program_learn(message: types.Message, state: FSMContext):
    await message.answer('👌', reply_markup = ReplyKeyboardRemove())
    await bot.delete_message(chat_id = message.from_user.id, message_id = message.message_id+1)
    txt = """Некоторые дисциплины образовательной программы "Управление проектом":
    🔘 проектный анализ и обоснование проекта;
    🔘 методология проектного управления;
    🔘 управление техническими аспектами управления проекта;
    🔘 управление рисками проекта;
    🔘 международные стандарты и сертификация прожект-менеджера;
    🔘 цифровые технологии в управлении проектами;
    🔘 event-management проектной деятельности;
    🔘 организация офиса проекта;
    🔘 тайм-менеджмент в проекте и др.

Занятия проводятся в формате лекций, семинаров, презентаций, деловых игр, тренингов, разбора внедрённых действующих проектов.

Формы обучения: очная, очно-заочная.
Вступительные испытания: математика, русский язык, обществознание.
Обучение: на бюджетной и договорной основах.
Стоимость обучения: на сайте приёмной комиссии ГУУ.
https://priem.guu.ru/"""
    key = InlineKeyboardMarkup(row_width = 1)
    for item in PROGRAM_LEARN.keys():
        if item in ['1 курс', '2 курс', '3 курс', '4 курс', 'Практика']:
            key.add(
                InlineKeyboardButton(
                    text = item,
                    callback_data = item
                )
            )
    key.add(InlineKeyboardButton(text = 'В меню', callback_data = 'menu')
        )
    await message.answer(txt, reply_markup = key, disable_web_page_preview = True)

@dp.callback_query_handler(text = PROGRAM_LEARN.keys())
async def program_learn(call: types.CallbackQuery,state: FSMContext):
    await bot.delete_message(chat_id = call.from_user.id, message_id = call.message.message_id)
    mess = PROGRAM_LEARN[call.data]
    key = InlineKeyboardMarkup(row_width = 1)
    for key_item in mess['button']:
        key.add(InlineKeyboardButton(text = key_item['text'], callback_data = key_item['callback_data']))

    if mess['image'] == None:
        await call.message.answer(mess['text'], reply_markup = key)
    else:
        await call.message.answer_photo(photo = open(mess['image'], 'rb'), caption = mess['text'], reply_markup = key)

@dp.callback_query_handler(text = 'our_partner')
async def our_partner(call: types.CallbackQuery, state: FSMContext):
    await bot.delete_message(chat_id = call.from_user.id, message_id = call.message.message_id)
    txt = """Это компании партнёры, которые уже ждут тебя на стажировку!
    ✅ Правительство Москвы
    ✅ Российское энергетическое агентство
    ✅ Объединенная судостроительная корпорация
    ✅ Фирма “1С
    ✅ Газпром
    ✅ Газпром “НЕФТЬ”
    ✅ Альфа банк
    ✅ АШАН
    ✅ Ростелеком
    ✅ Ernst & Young
    ✅ ENCE GmbH
    ✅ Deloitte
    ✅ РОСАТОМ
    ✅ РОСЭНЕРГОАТОМ
    ✅ GRM GROUP
    ✅ СОВНЕТ/IPMA
    ✅ Real Estate Zemer Consulting & Development
    ✅ НИАРМЕДИК"""#правка
    await call.message.answer_photo(photo = open('pictures/партнёры.jpg', 'rb'), caption = txt, reply_markup = keyboard.menu()['keyboard'])

@dp.message_handler(text = TEXT_MENU['rewievs_from_students'])
async def rewievs_from_students(message: types.Message,state: FSMContext):
    await message.answer('👌', reply_markup = ReplyKeyboardRemove())
    await bot.delete_message(chat_id = message.from_user.id, message_id = message.message_id+1)
    mess = REWIEVS[0]
    key = InlineKeyboardMarkup(row_width = 1)
    for key_item in mess['button']:
        key.add(InlineKeyboardButton(text = key_item['text'], callback_data = key_item['callback_data']))

    if mess['image'] == None:
        await message.answer(mess['text'], reply_markup = key)
    else:
        await message.answer_photo(photo = open(mess['image'], 'rb'), caption = mess['text'], reply_markup = key)
    await state.set_state('rewievs')
    await state.update_data(n = 0)

@dp.callback_query_handler(text = 'next', state = 'rewievs')
async def rewievs(call: types.CallbackQuery, state: FSMContext):
    await bot.delete_message(chat_id = call.from_user.id, message_id = call.message.message_id)
    async with state.proxy() as data:
        n = int(data.get('n')) + 1
        mess = REWIEVS[n]
        key = InlineKeyboardMarkup(row_width = 1)
        for key_item in mess['button']:
            key.add(InlineKeyboardButton(text = key_item['text'], callback_data = key_item['callback_data']))

        if mess['image'] == None:
            await call.message.answer(mess['text'], reply_markup = key)
        else:
            await call.message.answer_photo(photo = open(mess['image'], 'rb'), caption = mess['text'], reply_markup = key)
        await state.update_data(n = n)

@dp.message_handler(text = TEXT_MENU['freq_que'])
async def freq_que(message: types.Message, state: FSMContext):
    await message.answer('👌', reply_markup = ReplyKeyboardRemove())
    await bot.delete_message(chat_id = message.from_user.id, message_id = message.message_id+1)
    txt = """Частые вопросы"""
    key = InlineKeyboardMarkup(row_width = 1)
    for item in FREQ_QUE.keys():
        key.add(
            InlineKeyboardButton(
                text = item,
                callback_data = item[:10]
            )
        )
    key.add(InlineKeyboardButton(text = 'В меню', callback_data = 'menu'))
    await message.answer(txt, reply_markup = key, disable_web_page_preview = True)

@dp.callback_query_handler(text = 'freq_que')
async def freq_que_(call: types.CallbackQuery,state: FSMContext):
    await bot.delete_message(chat_id = call.from_user.id, message_id = call.message.message_id)
    txt = """Частые вопросы"""
    key = InlineKeyboardMarkup(row_width = 1)
    for item in FREQ_QUE.keys():
        key.add(
            InlineKeyboardButton(
                text = item,
                callback_data = item[:10]
            )
        )
    key.add(InlineKeyboardButton(text = 'В меню', callback_data = 'menu'))
    await call.message.answer(txt, reply_markup = key, disable_web_page_preview = True)

@dp.callback_query_handler(text = [x[:10] for x in FREQ_QUE.keys()])
async def freq_que_(call: types.CallbackQuery,state: FSMContext):
    await bot.delete_message(chat_id = call.from_user.id, message_id = call.message.message_id)
    for data in FREQ_QUE.keys():
        if call.data in data:
            call_data = data
            break
    mess = FREQ_QUE[call_data]
    key = InlineKeyboardMarkup(row_width = 1)
    for key_item in mess['button']:
        key.add(InlineKeyboardButton(text = key_item['text'], callback_data = key_item['callback_data']))

    if mess['image'] == None:
        await call.message.answer(mess['text'], reply_markup = key)
    else:
        await call.message.answer_photo(photo = open(mess['image'], 'rb'), caption = mess['text'], reply_markup = key)

@dp.callback_query_handler(text = 'menu', state = [None, 'rewievs'])
async def our_partner(call: types.CallbackQuery, state: FSMContext):
    await bot.delete_message(chat_id = call.from_user.id, message_id = call.message.message_id)
    #await call.message.answer(txt, reply_markup = keyboard.menu()['keyboard'])
    mess = keyboard.menu()
    await call.message.answer_photo(photo = mess['image'], caption = mess['text'], reply_markup = mess['keyboard'])
    await state.finish()

@dp.message_handler()
async def kal(message: types.Message, state: FSMContext):
    if message.text not in [x[1] for x in TEXT_MENU.items()]:
        await message.answer('Я не знаю как на такое реагировать\nНапиши /start')

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
