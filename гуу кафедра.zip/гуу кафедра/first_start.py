import importlib, subprocess, time

required_packages = {
    'aiogram' : 'aiogram', 
    'requests' : 'requests',
    'sqlite3': 'db-sqlite3'
}

# Проверяем наличие библиотек

while True:
    missing_packages = []
    for package in required_packages.keys():
        try:
            importlib.import_module(package)
        except ImportError:
            missing_packages.append(package)

    # Если есть отсутствующие библиотеки, устанавливаем их через pip
    if missing_packages:
        for package in missing_packages:
            print(f"Установка библиотеки {required_packages[package]}...")
            subprocess.run(['sudo', 'pip3', 'uninstall', '-y', required_packages[package] ])
            subprocess.run(['pip3', 'install', required_packages[package] ])

        time.sleep(5)
    else: 
        break

        
print("Все необходимые библиотеки установлены.")